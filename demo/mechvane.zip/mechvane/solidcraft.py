"""A synchronous stdio client for one `solidcraft-cli mcp` session."""

import json
import os
import queue
import subprocess
import sys
import tempfile
import threading
import time

from . import install


class SolidCraftError(RuntimeError):
    """A SolidCraft tool or command reported an error."""


_adapters_cache = None


def _windows_adapters() -> list[str]:
    """Names of the graphics adapters Windows reports, once per process; empty if the query fails."""
    global _adapters_cache
    if _adapters_cache is None:
        try:
            out = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command",
                 "(Get-CimInstance Win32_VideoController).Name"],
                capture_output=True, text=True, timeout=20,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
            _adapters_cache = [line.strip() for line in out.splitlines() if line.strip()]
        except (OSError, subprocess.SubprocessError):
            _adapters_cache = []
    return _adapters_cache


def session_env(platform=sys.platform, environ=None, adapters=None) -> dict:
    """Environment for `solidcraft-cli mcp`. On Windows with only Intel graphics wgpu uses DirectX 12
    unless WGPU_BACKEND is set: saving renders a preview through wgpu, and with Intel's Vulkan driver
    (igvk64.dll) that crashes the CLI with 0xC0000005 on any part with a curved face
    (docs/research/2026-10-29-windows-zylinder-absturz.md, SolidCraft #5589). With an NVIDIA or AMD card
    the default (Vulkan) stays: there DirectX 12 crashes the CLI while building a socket head screw
    (Windows 11 VM with an RTX 2070, 2026-11-01)."""
    env = dict(os.environ if environ is None else environ)
    if platform == "win32" and "WGPU_BACKEND" not in env:
        names = [a.lower() for a in (_windows_adapters() if adapters is None else adapters)]
        discrete = any(k in a for a in names for k in ("nvidia", "geforce", "quadro", "amd", "radeon"))
        if not discrete and any("intel" in a for a in names):
            env["WGPU_BACKEND"] = "dx12"
    return env


class Session:
    """One headless SolidCraft session (one open design)."""

    def __init__(self, allow_paths=(), executable=None, timeout=300.0):
        self.timeout = timeout
        self._closed = False
        # --headless: since 0.25 a plain `mcp` joins a running SolidCraft app instead; each Mechvane
        # document needs its own session
        args = [executable or install.find_cli(), "mcp", "--headless"]
        for p in allow_paths:
            args += ["--allow-path", str(p)]
        self._p = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                   stderr=subprocess.DEVNULL, text=True, bufsize=1, env=session_env(),
                                   encoding="utf-8", errors="replace")  # not the Windows ANSI code page
        self._n = 0
        # A reader thread instead of select() on the pipe, which Windows does not support.
        self._lines = queue.Queue()
        threading.Thread(target=self._reader, args=(self._p.stdout.fileno(), self._lines),
                         daemon=True).start()
        try:
            self._rpc("initialize", {"protocolVersion": "2025-06-18", "capabilities": {},
                                     "clientInfo": {"name": "mechvane", "version": "0.1"}})
            self._send({"jsonrpc": "2.0", "method": "notifications/initialized"})
        except Exception:
            self.close()
            raise

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def _send(self, msg):
        try:
            self._p.stdin.write(json.dumps(msg) + "\n")
            self._p.stdin.flush()
        except OSError as e:
            self.close()
            raise SolidCraftError(f"solidcraft-cli communication failed: {e}") from e

    @staticmethod
    def _reader(fd, lines):
        # Raw os.read, not the BufferedReader: a daemon thread blocked inside the buffered
        # reader holds its lock and aborts the interpreter at shutdown.
        buf = b""
        try:
            while True:
                chunk = os.read(fd, 65536)
                if not chunk:
                    break
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    lines.put(line)
        except OSError:
            pass
        lines.put(None)

    def _readline(self, timeout):
        try:
            line = self._lines.get(timeout=max(0.0, timeout))
        except queue.Empty:
            self.close()
            raise SolidCraftError(f"timeout waiting for solidcraft-cli response after {timeout}s")
        if line is None:
            self.close()
            raise SolidCraftError("solidcraft-cli mcp ended unexpectedly")
        return line.rstrip(b"\r").decode("utf-8")

    def _rpc(self, method, params, timeout=None):
        call_timeout = self.timeout if timeout is None else timeout
        self._n += 1
        self._send({"jsonrpc": "2.0", "id": self._n, "method": method, "params": params})
        deadline = time.monotonic() + call_timeout
        while True:
            remaining = max(0.0, deadline - time.monotonic())
            line = self._readline(remaining)
            if not line:
                self.close()
                raise SolidCraftError("solidcraft-cli mcp ended unexpectedly")
            msg = json.loads(line)
            if msg.get("id") == self._n:
                break
        if "error" in msg:
            raise SolidCraftError(f"{method}: {msg['error'].get('message', msg['error'])}")
        return msg["result"]

    def tool(self, name, args=None, timeout=None):
        """Call an MCP tool. Returns parsed JSON where the reply is JSON, else the text;
        images come back as {"image": base64, "mime": ...}."""
        res = self._rpc("tools/call", {"name": name, "arguments": args or {}}, timeout=timeout)
        texts, images = [], []
        for c in res.get("content", []):
            if c["type"] == "text":
                texts.append(c["text"])
            elif c["type"] == "image":
                images.append({"image": c["data"], "mime": c.get("mimeType", "image/png")})
        text = "\n".join(texts)
        if res.get("isError"):
            raise SolidCraftError(text)
        if images:
            return {"images": images, "text": text}
        try:
            return json.loads(text)
        except ValueError:
            pass
        # Since 0.25 a headless session appends a plain-text note after the JSON ("Note: this is a
        # headless session ..."): keep the JSON value at the start.
        try:
            value, end = json.JSONDecoder().raw_decode(text.lstrip())
        except ValueError:
            return text
        return value

    def cmd(self, command, params=None, timeout=None):
        """Run one engine command."""
        return self.tool("execute", {"command": command, "params": params or {}, "verbose": False}, timeout=timeout)

    def batch(self, commands, rollback=True, timeout=None):
        """Run steps all-or-nothing. Raises with the failing step's error."""
        r = self.tool("batch", {"commands": commands, "rollback": rollback, "verbose": False}, timeout=timeout)
        if isinstance(r, dict) and r.get("ok") is False:
            raise SolidCraftError(json.dumps(r.get("error", r))[:2000])
        return r

    def close(self):
        if self._closed or self._p is None:
            return
        self._closed = True
        try:
            if self._p.stdin and not self._p.stdin.closed:
                try:
                    self._p.stdin.close()
                except OSError:
                    pass
            self._p.wait(10)
        except (OSError, subprocess.TimeoutExpired):
            try:
                self._p.kill()
            except OSError:
                pass
            try:
                self._p.wait(5)
            except (OSError, subprocess.TimeoutExpired):
                pass
        finally:
            if self._p.stdout and not self._p.stdout.closed:
                try:
                    self._p.stdout.close()
                except OSError:
                    pass
            if self._p.poll() is not None:
                _remove_scratch_dirs(self._p.pid)


def _remove_scratch_dirs(pid):
    """Remove the empty `<temp>/solidcraft-mcp-<pid>-<n>` folders the server makes at startup
    and leaves behind on exit (SolidCraft 0.21.0); folders with content stay."""
    prefix = f"solidcraft-mcp-{pid}-"
    try:
        entries = list(os.scandir(tempfile.gettempdir()))
    except OSError:
        return
    for e in entries:
        if e.name.startswith(prefix):
            try:
                os.rmdir(e.path)
            except OSError:
                pass
