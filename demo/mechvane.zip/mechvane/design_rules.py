"""Design rule checks for parts: wall thickness, hole edge distances, thread engagement
depth, and FDM printability. Operates via the SolidCraft session."""

import math

from . import geometry as g, hole_tables

PROFILES = {
    "fdm_0.4": {
        "name": "FDM 3D-Druck (0.4 mm Düse)",
        "min_wall_thickness": 1.2,        # mm (3 perimeters @ 0.4mm nozzle)
        "hole_edge_distance_factor": 1.5, # >= 1.5 * d from edge to hole center
        "thread_depth_factor": 1.5,       # >= 1.5 * d thread engagement depth
        "min_hole_diameter": 2.0,         # mm
        "max_overhang_angle": 45.0,       # degrees from vertical
        "build_direction": [0, 0, 1],     # unit vector (+Z)
    },
    "cnc_alu": {
        "name": "CNC Fräsen (Aluminium)",
        "min_wall_thickness": 1.0,        # mm
        "hole_edge_distance_factor": 1.5, # >= 1.5 * d from edge to hole center
        "thread_depth_factor": 1.5,       # >= 1.5 * d thread engagement depth
        "min_hole_diameter": 1.0,         # mm
        "max_overhang_angle": None,       # no overhang constraint
    },
}

BUILD_DIRECTIONS = {
    "+Z": [0, 0, 1],
    "-Z": [0, 0, -1],
    "+X": [1, 0, 0],
    "-X": [-1, 0, 0],
    "+Y": [0, 1, 0],
    "-Y": [0, -1, 0],
}


def parse_build_direction(val, allow_vector: bool = True) -> list[float]:
    """Parse build_direction from '+Z|-Z|+X|-X|+Y|-Y' or (if allow_vector) a 3D unit vector."""
    if isinstance(val, str):
        key = val.strip().upper()
        if key in BUILD_DIRECTIONS:
            return list(BUILD_DIRECTIONS[key])
        raise ValueError(
            f"invalid build_direction {val!r}, expected one of: {', '.join(BUILD_DIRECTIONS)}"
        )
    if allow_vector and isinstance(val, (list, tuple)) and len(val) == 3:
        if all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in val):
            n = g.norm(val)
            if n > 1e-9:
                u = [float(x) / n for x in val]
                for vec in BUILD_DIRECTIONS.values():
                    if g.dot(u, vec) > 1.0 - 1e-9:
                        return list(vec)
                return u
    raise ValueError(
        f"invalid build_direction {val!r}, expected one of: {', '.join(BUILD_DIRECTIONS)}"
    )


def _format_build_direction(d: list[float]) -> str:
    for name, vec in BUILD_DIRECTIONS.items():
        if g.dot(d, vec) > 1.0 - 1e-6:
            return f"{name} ({vec})"
    return str([round(x, 4) for x in d])

# ISO metric coarse threads: (nominal_diameter_mm, pitch_mm, tap_drill_diameter_mm)
ISO_METRIC_THREADS = [
    (2.0, 0.4, 1.6),
    (2.5, 0.45, 2.05),
    (3.0, 0.5, 2.5),
    (4.0, 0.7, 3.3),
    (5.0, 0.8, 4.2),
    (6.0, 1.0, 5.0),
    (8.0, 1.25, 6.8),
    (10.0, 1.5, 8.5),
    (12.0, 1.75, 10.2),
    (14.0, 2.0, 12.0),
    (16.0, 2.0, 14.0),
    (20.0, 2.5, 17.5),
]


def match_iso_tap_drill(diameter: float) -> tuple[float, float, float] | None:
    """Find ISO metric thread matching tap drill (Kernloch) diameter within +/-0.15 mm."""
    for nom_d, pitch, tap_drill in ISO_METRIC_THREADS:
        if abs(diameter - tap_drill) <= 0.15:
            return nom_d, pitch, tap_drill
    return None


def _get_cfg(profile: str | dict, build_direction: str | list[float] | None = None) -> dict:
    if isinstance(profile, str):
        if profile not in PROFILES:
            raise ValueError(f"unknown profile {profile!r}, available: {', '.join(PROFILES)}")
        base = dict(PROFILES[profile])
    elif isinstance(profile, dict):
        base = dict(PROFILES.get("fdm_0.4", {}))
        base.update(profile)
    else:
        raise TypeError(f"profile must be str or dict, got {type(profile).__name__}")
    if build_direction is not None:
        base["build_direction"] = parse_build_direction(build_direction)
    elif base.get("build_direction") is not None:
        base["build_direction"] = parse_build_direction(base["build_direction"])
    else:
        base["build_direction"] = [0, 0, 1]
    return base


_eval_length = g.eval_length


def _extract_holes(session, body_name: str, faces: list[dict], bbox: dict,
                   timeline_map: dict, threads: list[dict]) -> tuple[list[dict], list[dict]]:
    """Group cylindrical faces sharing an axis and radius into logical holes and external cylinders."""
    cyl_faces = [f for f in faces if f.get("cylinder")]
    feat_cyl_faces = {}
    for f in cyl_faces:
        parts = f["name"].split(":")
        fid = parts[0] if parts[0].startswith("F") and parts[0][1:].isdigit() else None
        feat_cyl_faces.setdefault(fid, []).append(f)

    groups = []
    for f_list in feat_cyl_faces.values():
        groups.extend(g.group_cylindrical_faces(f_list))

    is_hole_list = g.classify_hole_groups(session, body_name, groups, timeline_map, threads, bbox)

    holes = []
    ext_cylinders = []
    for grp, is_hole in zip(groups, is_hole_list):
        r = grp[0]["cylinder"]["radius"]
        d = 2.0 * r
        axis = g.unit(grp[0]["cylinder"]["axis"])
        p0 = grp[0]["cylinder"]["origin"]
        total_area = sum(f["area"] for f in grp)
        length = g.cylinder_group_length(grp)

        # Center along axis
        weighted_t = sum(f["area"] * g.dot(g.sub(f["centroid"], p0), axis) for f in grp) / total_area
        center = g.add(p0, g.scale(axis, weighted_t))
        rep_pt = grp[0].get("point") or grp[0].get("centroid") or center

        if not is_hole:
            ext_cylinders.append({
                "faces": [f["name"] for f in grp],
                "representative_point": rep_pt,
                "radius": r,
                "diameter": d,
                "axis": axis,
                "origin": p0,
                "center": center,
                "length": length,
            })
            continue

        # Associated feature id from face name F{id}:...
        feat_id = None
        for f in grp:
            parts = f["name"].split(":")
            if parts[0].startswith("F") and parts[0][1:].isdigit():
                feat_id = int(parts[0][1:])
                break
        feat_info = timeline_map.get(feat_id, {})

        # Blind hole check
        is_blind = False
        if feat_info.get("type") == "HoleFeature":
            defn = feat_info.get("definition", {})
            if "depth" in defn and "to" not in defn:
                # the floor of a counterbore or countersink is no hole bottom
                end_caps = [f for f in faces if f["name"].startswith(f"F{feat_id}:") and not f.get("cylinder")
                            and ":cbore:" not in f["name"] and ":csink:" not in f["name"]] if feat_id is not None else []
                if end_caps:
                    is_blind = True
        elif feat_id is not None:
            # End cap faces belonging to this feature
            end_caps = [f for f in faces if f["name"].startswith(f"F{feat_id}:") and not f.get("cylinder")]
            if end_caps:
                is_blind = True

        holes.append({
            "faces": [f["name"] for f in grp],
            "representative_point": grp[0]["point"],
            "radius": r,
            "diameter": d,
            "axis": axis,
            "center": center,
            "length": length,
            "feature": feat_info,
            "is_blind": is_blind,
            "thread": None,
        })

    # Thread match: internal threads matched by collinearity and axial overlap.
    # Each thread is assigned to at most one hole, matching highest axial overlap first.
    candidates = []
    for h_idx, h in enumerate(holes):
        h_axis = h["axis"]
        h_center = h["center"]
        h_L = h.get("length", 0.0)
        c_proj = g.dot(h_center, h_axis)
        h_t_min = c_proj - h_L / 2.0
        h_t_max = c_proj + h_L / 2.0
        for th_idx, th in enumerate(threads):
            if not th.get("internal"):
                continue
            th_axis = th.get("axis")
            if th_axis and not g.parallel(th_axis, h_axis, tol=1e-3):
                continue
            if g.dist_to_line(th["axis_point"], h_center, h_axis) >= 0.05:
                continue
            t_axis = g.unit(th_axis) if th_axis else h_axis
            th_start_pt = g.add(th["axis_point"], g.scale(t_axis, th.get("start", 0.0)))
            th_end_pt = g.add(th["axis_point"], g.scale(t_axis, th.get("end", 0.0)))
            t_th_start = g.dot(th_start_pt, h_axis)
            t_th_end = g.dot(th_end_pt, h_axis)
            th_t_min = min(t_th_start, t_th_end)
            th_t_max = max(t_th_start, t_th_end)
            overlap = min(h_t_max, th_t_max) - max(h_t_min, th_t_min)
            axial_dist = abs((th_t_min + th_t_max) / 2.0 - c_proj)
            if overlap > -0.05:
                candidates.append((overlap, -axial_dist, h_idx, th_idx))

    used_holes = set()
    used_threads = set()
    for overlap, neg_dist, h_idx, th_idx in sorted(candidates, reverse=True):
        if h_idx not in used_holes and th_idx not in used_threads:
            holes[h_idx]["thread"] = threads[th_idx]
            used_holes.add(h_idx)
            used_threads.add(th_idx)

    return holes, ext_cylinders


def _check_body(session, body: dict, timeline_map: dict, threads: list[dict], cfg: dict) -> dict:
    faces = session.cmd("model.faces", {"body": body["name"]}).get("faces", [])
    try:
        edges = session.cmd("model.edges", {"body": body["name"]}).get("edges", [])
    except Exception:
        edges = []
    bbox = body["bbox"]
    holes, ext_cyls = _extract_holes(session, body["name"], faces, bbox, timeline_map, threads)

    rules = {
        "min_wall_thickness": {"status": "ok", "findings": []},
        "hole_edge_distance": {"status": "ok", "findings": []},
        "thread_depth": {"status": "ok", "findings": []},
        "printability": {"status": "ok", "findings": []},
        "countersink_clearance": {"status": "ok", "findings": []},
    }

    # A countersink tool only leaves its flat top face (`csink:base`) when it cut material above
    # the entry face, i.e. it notched a neighbouring wall (SolidCraft cuts the cone past the entry).
    for f in faces:
        if f.get("name", "").split("#")[0].endswith(":csink:base"):
            rules["countersink_clearance"]["status"] = "fail"
            rules["countersink_clearance"]["findings"].append({
                "status": "fail",
                "location": {"point": f.get("point") or f.get("centroid"), "face": f["name"]},
                "message": (f"Countersink cuts into material above its entry face (face {f['name']}): "
                            "a neighbouring wall is notched, move the hole away or use a counterbore"),
            })

    min_wall = cfg["min_wall_thickness"]
    edge_factor = cfg["hole_edge_distance_factor"]

    # 1. Hole edge distance and wall thickness to boundaries
    for h in holes:
        c, r, d, axis = h["center"], h["radius"], h["diameter"], h["axis"]

        # Axial range of the hole along its cylinder axis
        hole_edges = [e for e in edges if any(g.edge_touches(e.get("name", ""), fn) for fn in h["faces"])]
        if hole_edges:
            hole_pts = [e["start"] for e in hole_edges] + [e["end"] for e in hole_edges]
            t_h_min = min(g.dot(pt, axis) for pt in hole_pts)
            t_h_max = max(g.dot(pt, axis) for pt in hole_pts)
        else:
            c_proj = g.dot(c, axis)
            L = h.get("length", 0.0)
            t_h_min = c_proj - L / 2.0
            t_h_max = c_proj + L / 2.0
        h["t_range"] = (t_h_min, t_h_max)

        side_faces = [f for f in faces if f.get("plane_normal") and abs(g.dot(f["plane_normal"], axis)) < 0.1]
        dist_faces = []
        for sf in side_faces:
            n = sf["plane_normal"]
            v_to_plane = g.sub(sf["point"], c)
            signed_dist = g.dot(v_to_plane, n)
            # Face normal must point outward from the hole, not inward as in interior steps/pockets
            if signed_dist < -1e-4:
                continue

            f_edges = [e for e in edges if g.edge_touches(e.get("name", ""), sf["name"])]
            if f_edges:
                sf_pts = [e["start"] for e in f_edges] + [e["end"] for e in f_edges]
                t_sf_min = min(g.dot(pt, axis) for pt in sf_pts)
                t_sf_max = max(g.dot(pt, axis) for pt in sf_pts)
                # Face must actually overlap the hole along the hole axis
                overlap = min(t_sf_max, t_h_max) - max(t_sf_min, t_h_min)
                if overlap < 1e-3:
                    continue

                # Face must cover the hole in the transverse direction perpendicular to axis and normal
                u_trans = g.unit(g.cross(axis, n))
                u_hole = g.dot(c, u_trans)
                u_sf_min = min(g.dot(pt, u_trans) for pt in sf_pts)
                u_sf_max = max(g.dot(pt, u_trans) for pt in sf_pts)
                if u_hole < u_sf_min - r - 1e-4 or u_hole > u_sf_max + r + 1e-4:
                    continue

            dist = abs(signed_dist)
            dist_faces.append((dist, sf["name"]))

        # Non-coaxial external cylindrical walls contribute to edge distance
        for ec in ext_cyls:
            if not g.parallel(axis, ec["axis"], tol=1e-3):
                continue
            d_axes = g.dist_to_line(c, ec["origin"], ec["axis"])
            if d_axes < 0.05:
                # Coaxial cylinder (Dom): handled in wall thickness check below
                continue
            ec_edges = [e for e in edges if any(g.edge_touches(e.get("name", ""), fn) for fn in ec["faces"])]
            if ec_edges:
                ec_pts = [e["start"] for e in ec_edges] + [e["end"] for e in ec_edges]
                t_ec_min = min(g.dot(pt, axis) for pt in ec_pts)
                t_ec_max = max(g.dot(pt, axis) for pt in ec_pts)
            else:
                c_proj = g.dot(ec["center"], axis)
                L = ec.get("length", 0.0)
                t_ec_min = c_proj - L / 2.0
                t_ec_max = c_proj + L / 2.0
            overlap = min(t_ec_max, t_h_max) - max(t_ec_min, t_h_min)
            if overlap < 1e-3:
                continue

            if d_axes + r <= ec["radius"] + 1e-4:
                dist = ec["radius"] - d_axes
            else:
                dist = d_axes - ec["radius"]
            dist_faces.append((dist, ec["faces"][0]))

        # Distance to bounding box only along lateral axes orthogonal to cylinder axis
        d_box = []
        for i in (0, 1, 2):
            if abs(axis[i]) < 0.5:
                d_box.append(min(abs(c[i] - bbox["min"][i]), abs(c[i] - bbox["max"][i])))
        dist_bbox = min(d_box) if d_box else float("inf")

        if dist_faces:
            min_dist, nearest_face = min(dist_faces, key=lambda x: x[0])
            min_dist = min(min_dist, dist_bbox)
        else:
            min_dist, nearest_face = dist_bbox, "bbox"

        req_edge = edge_factor * d
        if any(":cbore:" in fn for fn in h["faces"]):
            pass  # a counterbore is the head recess of its bore: the bore's own edge distance and the wall count
        elif min_dist < req_edge - 1e-4:
            rules["hole_edge_distance"]["status"] = "fail"
            rules["hole_edge_distance"]["findings"].append({
                "status": "fail",
                "location": {"point": h["representative_point"], "face": h["faces"][0]},
                "message": (f"Hole edge distance {min_dist:.2f} mm < {req_edge:.2f} mm "
                            f"({edge_factor:.1f} × d for Ø {d:.1f} mm) to face {nearest_face}"),
                "value": round(min_dist, 4),
                "threshold": round(req_edge, 4),
            })
        else:
            rules["hole_edge_distance"]["findings"].append({
                "status": "ok",
                "location": {"point": h["representative_point"], "face": h["faces"][0]},
                "message": (f"Hole edge distance {min_dist:.2f} mm >= {req_edge:.2f} mm "
                            f"({edge_factor:.1f} × d for Ø {d:.1f} mm)"),
                "value": round(min_dist, 4),
                "threshold": round(req_edge, 4),
            })

        w_edge = max(0.0, min_dist - r)
        w_face = nearest_face

        # Wall thickness check for hollow cylinders (Dom: R_outer - r_inner) and nearest external cylinder walls
        for ec in ext_cyls:
            if not g.parallel(axis, ec["axis"], tol=1e-3):
                continue
            d_axes = g.dist_to_line(c, ec["origin"], ec["axis"])
            ec_edges = [e for e in edges if any(g.edge_touches(e.get("name", ""), fn) for fn in ec["faces"])]
            if ec_edges:
                ec_pts = [e["start"] for e in ec_edges] + [e["end"] for e in ec_edges]
                t_ec_min = min(g.dot(pt, axis) for pt in ec_pts)
                t_ec_max = max(g.dot(pt, axis) for pt in ec_pts)
            else:
                c_proj = g.dot(ec["center"], axis)
                L = ec.get("length", 0.0)
                t_ec_min = c_proj - L / 2.0
                t_ec_max = c_proj + L / 2.0
            overlap = min(t_ec_max, t_h_max) - max(t_ec_min, t_h_min)
            if overlap < 1e-3:
                continue

            if d_axes < 0.05:
                # Coaxial hollow cylinder / Dom: wall = R_outer - r_inner
                w_cyl = max(0.0, ec["radius"] - r)
            elif d_axes + r <= ec["radius"] + 1e-4:
                w_cyl = max(0.0, ec["radius"] - d_axes - r)
            else:
                w_cyl = max(0.0, d_axes - ec["radius"] - r)

            if w_cyl < w_edge:
                w_edge = w_cyl
                w_face = ec["faces"][0]

        if w_edge < min_wall - 1e-4:
            rules["min_wall_thickness"]["status"] = "fail"
            rules["min_wall_thickness"]["findings"].append({
                "status": "fail",
                "location": {"point": h["representative_point"], "face": h["faces"][0]},
                "message": (f"Wall thickness to edge is {w_edge:.2f} mm < {min_wall:.2f} mm "
                            f"for hole Ø {d:.1f} mm"),
                "value": round(w_edge, 4),
                "threshold": round(min_wall, 4),
            })
        else:
            rules["min_wall_thickness"]["findings"].append({
                "status": "ok",
                "location": {"point": h["representative_point"], "face": h["faces"][0]},
                "message": f"Wall thickness to edge is {w_edge:.2f} mm >= {min_wall:.2f} mm",
                "value": round(w_edge, 4),
                "threshold": round(min_wall, 4),
            })

    # Wall thickness between adjacent holes
    for i in range(len(holes)):
        for j in range(i + 1, len(holes)):
            h1, h2 = holes[i], holes[j]
            if g.parallel(h1["axis"], h2["axis"], tol=1e-3):
                # Coaxial holes (e.g. counterbore and bore of the same stepped hole) are not adjacent holes
                if g.dist_to_line(h1["center"], h2["center"], h1["axis"]) < 0.05:
                    continue
                # Holes that do not overlap along their axis (e.g. blind holes from opposite sides)
                # are separated by material along the axis, not by a wall between them
                if "t_range" in h1 and "t_range" in h2:
                    sign = 1.0 if g.dot(h1["axis"], h2["axis"]) > 0 else -1.0
                    r2 = sorted(sign * t for t in h2["t_range"])
                    if min(h1["t_range"][1], r2[1]) - max(h1["t_range"][0], r2[0]) < 1e-3:
                        continue
                delta = g.sub(h1["center"], h2["center"])
                proj_dist = g.norm(g.sub(delta, g.scale(h1["axis"], g.dot(delta, h1["axis"]))))
                w_between = proj_dist - (h1["radius"] + h2["radius"])
                if w_between < min_wall - 1e-4:
                    rules["min_wall_thickness"]["status"] = "fail"
                    rules["min_wall_thickness"]["findings"].append({
                        "status": "fail",
                        "location": {"point": h1["representative_point"], "face": h1["faces"][0]},
                        "message": (f"Wall thickness between holes is {w_between:.2f} mm < {min_wall:.2f} mm "
                                    f"({h1['faces'][0]} to {h2['faces'][0]})"),
                        "value": round(w_between, 4),
                        "threshold": round(min_wall, 4),
                    })

    # Minimum body dimensions
    b_dims = [bbox["max"][k] - bbox["min"][k] for k in range(3)]
    min_dim = min(b_dims)
    if min_dim < min_wall - 1e-4:
        rules["min_wall_thickness"]["status"] = "fail"
        rules["min_wall_thickness"]["findings"].append({
            "status": "fail",
            "location": {"point": body.get("center_of_mass", bbox["min"]), "body": body["name"]},
            "message": f"Body minimum dimension {min_dim:.2f} mm < {min_wall:.2f} mm",
            "value": round(min_dim, 4),
            "threshold": round(min_wall, 4),
        })

    # 2. Thread engagement depth
    thread_factor = cfg["thread_depth_factor"]
    for h in holes:
        # Counterbores are bolt head recesses, never threaded
        if any(":cbore:" in fn for fn in h["faces"]):
            continue
        th = h["thread"]
        feat_defn = h["feature"].get("definition", {})
        # Clearance holes (e.g. ISO 273 clearance) carry fasteners through, never internal threads
        if "clearance" in feat_defn:
            continue
        thread_spec = th.get("designation") if th else feat_defn.get("thread")

        nom_d = None
        if thread_spec:
            if thread_spec.upper().startswith("M"):
                try:
                    nom_d = float(thread_spec[1:].split("X")[0].split("x")[0])
                except ValueError:
                    pass
        if not nom_d and (h["is_blind"] or h["thread"] or feat_defn.get("thread")):
            matched = match_iso_tap_drill(h["diameter"])
            if matched:
                nom_d, pitch, tap_drill = matched
                thread_spec = f"M{nom_d:.0f} tap drill (Kernloch Ø {tap_drill:.1f} mm)"

        if nom_d:
            req_depth = thread_factor * nom_d
            if th:
                act_depth = abs(th["end"] - th["start"])
            else:
                depth_val = _eval_length(session, feat_defn.get("depth"), default=h["length"])
                act_depth = min(depth_val, h["length"]) if depth_val else h["length"]
            if act_depth < req_depth - 1e-4:
                rules["thread_depth"]["status"] = "fail"
                rules["thread_depth"]["findings"].append({
                    "status": "fail",
                    "location": {"point": h["representative_point"], "face": h["faces"][0]},
                    "message": (f"Thread engagement depth {act_depth:.1f} mm < {req_depth:.1f} mm "
                                f"({thread_factor:.1f} × d for {thread_spec}{cfg.get('thread_depth_basis', '')})"),
                    "value": round(act_depth, 4),
                    "threshold": round(req_depth, 4),
                })
            else:
                rules["thread_depth"]["findings"].append({
                    "status": "ok",
                    "location": {"point": h["representative_point"], "face": h["faces"][0]},
                    "message": (f"Thread engagement depth {act_depth:.1f} mm >= {req_depth:.1f} mm "
                                f"({thread_factor:.1f} × d for {thread_spec}{cfg.get('thread_depth_basis', '')})"),
                    "value": round(act_depth, 4),
                    "threshold": round(req_depth, 4),
                })
        elif h["is_blind"]:
            req_depth = thread_factor * h["diameter"]
            depth_val = _eval_length(session, feat_defn.get("depth"), default=h["length"])
            act_depth = min(depth_val, h["length"]) if depth_val else h["length"]
            if act_depth < req_depth - 1e-4:
                if rules["thread_depth"]["status"] != "fail":
                    rules["thread_depth"]["status"] = "warn"
                rules["thread_depth"]["findings"].append({
                    "status": "warn",
                    "location": {"point": h["representative_point"], "face": h["faces"][0]},
                    "message": (f"Blind hole depth {act_depth:.1f} mm < {req_depth:.1f} mm "
                                f"({thread_factor:.1f} × d if intended for threaded fasteners)"),
                    "value": round(act_depth, 4),
                    "threshold": round(req_depth, 4),
                })

    # 3. Printability (FDM overhangs and small holes)
    max_oh = cfg.get("max_overhang_angle")
    if max_oh is not None:
        d = g.unit(cfg.get("build_direction") or [0, 0, 1])
        dir_label = _format_build_direction(d)
        lo, hi = bbox["min"], bbox["max"]
        corners = [[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])]
        h_min = min(g.dot(c, d) for c in corners)
        sin_limit = math.sin(math.radians(max_oh))
        for f in faces:
            n = f.get("plane_normal")
            if not n:
                continue
            nd = g.dot(n, d)
            if nd >= -0.01:
                continue
            # Build plate check
            if nd <= -0.99 and abs(g.dot(f["centroid"], d) - h_min) < 0.05:
                continue

            # Downward face above print bed
            if nd < -sin_limit:
                rules["printability"]["status"] = "fail"
                rules["printability"]["findings"].append({
                    "status": "fail",
                    "location": {"point": f["centroid"], "face": f["name"]},
                    "message": (f"Unsupported overhang on face {f['name']} (normal {n}, centroid {f['centroid']}) "
                                f"exceeds {max_oh:.0f}° limit in build direction {dir_label}"),
                })

    min_hole_d = cfg.get("min_hole_diameter", 0)
    for h in holes:
        if h["diameter"] < min_hole_d - 1e-4:
            if rules["printability"]["status"] != "fail":
                rules["printability"]["status"] = "warn"
            rules["printability"]["findings"].append({
                "status": "warn",
                "location": {"point": h["representative_point"], "face": h["faces"][0]},
                "message": (f"Hole diameter {h['diameter']:.1f} mm < {min_hole_d:.1f} mm "
                            f"(FDM minimum hole diameter for 0.4 mm nozzle)"),
                "value": round(h["diameter"], 4),
                "threshold": round(min_hole_d, 4),
            })

    return rules


def body_material(session) -> str | None:
    """The material assigned to the part's bodies in SolidCraft (material.assign), as a key of the
    engagement table; None when unassigned (Default), mixed or not in the table."""
    # only the measure tool reports the material; document.inspect leaves it out
    bodies = session.tool("measure", {}).get("bodies", [])
    names = {b.get("material") for b in bodies} - {None, "Default"}
    if len(names) != 1:
        return None
    try:
        return hole_tables.normalize_material(names.pop())
    except ValueError:
        return None


def saved_rules(doc) -> dict:
    """Profile and material saved in the part file (save_rules), {} for none or a bare session."""
    if not hasattr(doc, "metadata"):
        return {}
    return dict(doc.metadata().get("rules") or {})


def save_rules(doc, profile: str | None = None, material: str | None = None) -> dict:
    """Save the profile and material for the design rules in the part file's metadata and save the file.

    An empty material clears it (the bodies' SolidCraft material applies again)."""
    rules = saved_rules(doc)
    if profile is not None:
        _get_cfg(profile)  # unknown profile: ValueError, nothing saved
        rules["profile"] = profile
    if material is not None:
        if material:
            rules["material"] = hole_tables.normalize_material(material)
        else:
            rules.pop("material", None)
    meta = doc.metadata()
    meta["rules"] = rules
    doc.set_metadata(meta)
    doc.save()
    return rules


def check(session_or_doc, profile: str | dict | None = None,
          build_direction: str | list[float] | None = None, material: str | None = None) -> dict:
    """Check a part against design rules using the open SolidCraft session.

    profile: without it the profile saved in the part file (save_rules) applies, else fdm_0.4.
    material: the part's material (steel, cast_iron, alu, alu_wrought, brass, ...): the thread depth
    then follows the engagement table in hole_tables instead of the profile's flat factor. Without it
    the material saved in the part file applies, then the material assigned to the bodies in
    SolidCraft, if the table knows it."""
    session = getattr(session_or_doc, "session", session_or_doc)
    saved = saved_rules(session_or_doc)
    if profile is None:
        profile = saved.get("profile") or "fdm_0.4"
    cfg = _get_cfg(profile, build_direction=build_direction)
    material_source = "argument" if material else None
    if not material and saved.get("material"):
        material, material_source = saved["material"], "saved"
    if not material:
        material = body_material(session)
        material_source = "body" if material else None
    if material:
        mat = hole_tables.normalize_material(material)
        entry = hole_tables.MATERIAL_ENGAGEMENT_DEPTHS[mat]
        cfg["thread_depth_factor"] = entry["factor"]
        cfg["thread_depth_basis"] = f" in {mat}" + ("" if entry.get("verified") else ", unverified value")
    profile_name = profile if isinstance(profile, str) else cfg.get("name", "custom")

    doc_info = session.cmd("document.inspect", {"measure": True})
    bodies = doc_info.get("bodies", [])
    timeline = doc_info.get("timeline", [])
    threads = session.cmd("model.threads").get("threads", [])

    tl_map = {f["id"]: f for f in timeline if isinstance(f, dict) and "id" in f}
    for f in tl_map.values():
        if f.get("type") in ("HoleFeature", "CylinderFeature", "ExtrudeFeature") and not f.get("definition"):
            try:
                insp = session.cmd("timeline.inspect", {"feature": f["id"]})
                if isinstance(insp, dict):
                    f["definition"] = insp.get("definition", {})
            except Exception:
                pass

    all_rules = {
        "min_wall_thickness": {"status": "ok", "findings": []},
        "hole_edge_distance": {"status": "ok", "findings": []},
        "thread_depth": {"status": "ok", "findings": []},
        "printability": {"status": "ok", "findings": []},
        "countersink_clearance": {"status": "ok", "findings": []},
    }

    for body in bodies:
        b_rules = _check_body(session, body, tl_map, threads, cfg)
        for r_name, r_data in b_rules.items():
            all_rules[r_name]["findings"].extend(r_data["findings"])
            if r_data["status"] == "fail":
                all_rules[r_name]["status"] = "fail"
            elif r_data["status"] == "warn" and all_rules[r_name]["status"] != "fail":
                all_rules[r_name]["status"] = "warn"

    flat_checks = []
    for r_name, r_data in all_rules.items():
        for f in r_data["findings"]:
            flat_checks.append(dict(f, rule=r_name))

    has_fail = any(r["status"] == "fail" for r in all_rules.values())
    has_warn = any(r["status"] == "warn" for r in all_rules.values())
    verdict = "fail" if has_fail else ("warn" if has_warn else "ok")

    failed_rules = [k for k, v in all_rules.items() if v["status"] == "fail"]
    warn_rules = [k for k, v in all_rules.items() if v["status"] == "warn"]

    if not bodies:
        # nothing to check is no pass
        verdict = "warn"
        summary = f"Design check ({profile_name}): WARN - the part has no solid bodies"
    elif verdict == "ok":
        summary = f"Design check ({profile_name}): OK - all rules passed"
    elif verdict == "fail":
        summary = f"Design check ({profile_name}): FAIL - failed rules: {', '.join(failed_rules)}"
    else:
        summary = f"Design check ({profile_name}): WARN - warnings in: {', '.join(warn_rules)}"

    return {
        "status": verdict,
        "verdict": verdict,
        "profile": profile_name,
        "material": material,
        "material_source": material_source,
        "rules": all_rules,
        "checks": flat_checks,
        "summary": summary,
    }
